console.log("Code.js loaded");

$(init)

function init() {
    var test = new GamingController();
    test.init("gamescreen", "start", 5);
}