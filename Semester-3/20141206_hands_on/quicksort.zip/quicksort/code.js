console.log("Code.js loaded")

$(init)

function init() {
    
}

function gameLoop() {
    update()
    draw()
}

function update() {
    
}

function draw() {
    
}
